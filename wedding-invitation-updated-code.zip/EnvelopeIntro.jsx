import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, MapPin, Heart } from 'lucide-react';
import confetti from 'canvas-confetti';
import weddingConfig from '../../config/weddingConfig';
import { useAudio } from '../../context/AudioContext';
import { useLanguage } from '../../context/LanguageContext';
import Sparkles from '../Sparkles/Sparkles';
import styles from './EnvelopeIntro.module.css';

export default function EnvelopeIntro({ isVisible, onOpenComplete }) {
  // State: 'closed' | 'opening' | 'expanding' | 'done'
  const [phase, setPhase] = useState('closed');
  const transitionTimers = useRef([]);
  const { playAudio } = useAudio();
  const { t, language } = useLanguage();

  useEffect(() => () => {
    transitionTimers.current.forEach((timer) => clearTimeout(timer));
  }, []);

  const handleSparkleClick = async () => {
    if (phase !== 'closed') return;

    // 1. Play background music immediately
    try {
      await playAudio();
    } catch {
      // Opening the card should still work if audio is unavailable.
    }

    // 2. Trigger golden sparkles/confetti burst from the opening point
    try {
      confetti({
        particleCount: 65,
        spread: 90,
        origin: { x: 0.5, y: 0.48 },
        colors: ['#f5dfa6', '#d4a857', '#ffffff', '#e8c882', '#b38738'],
        ticks: 200,
        gravity: 0.85,
        scalar: 1,
      });
    } catch {
      // Ignore if canvas-confetti is not available
    }

    // 3. Flap opens
    setPhase('opening');

    // 4. Card comes up and starts expanding to appear as first section
    transitionTimers.current.push(setTimeout(() => {
      setPhase('expanding');
    }, 950));

    // 5. Seamlessly hand off to main content
    transitionTimers.current.push(setTimeout(() => {
      setPhase('done');
      onOpenComplete();
    }, 3100));
  };

  const handleSparkleKeyDown = (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleSparkleClick();
    }
  };

  if (!isVisible || phase === 'done') return null;

  return (
    <AnimatePresence>
      <motion.div
        className={styles.envelopeGate}
        initial={{ opacity: 1 }}
        animate={
          phase === 'expanding'
            ? {
                opacity: [1, 1, 0],
                transition: { duration: 1.7, times: [0, 0.65, 1], ease: 'easeInOut' },
              }
            : { opacity: 1 }
        }
        exit={{ opacity: 0 }}
      >
        {/* Ambient floating stardust */}
        <Sparkles count={36} />

        <div className={styles.envelopePerspectiveWrapper}>
          {/* Header Flourish (fades out as card expands) */}
          <motion.div
            className={styles.topFlourish}
            animate={phase !== 'closed' ? { opacity: 0, y: -20 } : { opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className={styles.emblemSymbol}>❦</span>
            <span className={styles.emblemText}>{t.envelope.header}</span>
          </motion.div>

          <div className={styles.envelopeContainer}>
            {/* The Envelope Body */}
            <motion.div
              className={styles.envelopeBody}
              animate={
                phase === 'expanding'
                  ? {
                      y: 180,
                      opacity: 0,
                      scale: 0.9,
                      transition: { duration: 1.1, ease: [0.32, 0, 0.67, 0] },
                    }
                  : { y: 0, opacity: 1, scale: 1 }
              }
            >
              {/* Back lining inside envelope pocket */}
              <div className={styles.envelopeBackLining} />

              {/* ══════════════════════════════════════════════════════
                  THE CARD INSIDE (Comes up, gets bigger, appears like first section)
                  ══════════════════════════════════════════════════════ */}
              <motion.div
                className={styles.innerCard}
                initial={{ y: 20, scale: 0.92, opacity: 0 }}
                animate={
                  phase === 'closed'
                    ? { y: 20, scale: 0.92, opacity: 0 }
                    : phase === 'opening'
                    ? {
                        y: -140,
                        scale: 1.02,
                        opacity: 1,
                        transition: { duration: 0.95, ease: [0.22, 1, 0.36, 1] },
                      }
                    : {
                        // Expanding phase: card comes up higher, gets bigger and fills screen
                        y: -80,
                        scale: [1.02, 1.12, 1.48],
                        opacity: [1, 1, 0.96],
                        transition: { duration: 2.15, times: [0, 0.55, 1], ease: [0.16, 1, 0.3, 1] },
                      }
                }
              >
                <div className={styles.cardFrame}>
                  {/* Ornate corner ornaments */}
                  <div className={`${styles.corner} ${styles.cTopLeft}`} />
                  <div className={`${styles.corner} ${styles.cTopRight}`} />
                  <div className={`${styles.corner} ${styles.cBottomLeft}`} />
                  <div className={`${styles.corner} ${styles.cBottomRight}`} />

                  {/* Card Header & Monogram */}
                  <div className={styles.cardTop}>
                    <span className={styles.cardTag}>
                      {language === 'en' ? 'SAVE THE DATE • WEDDING INVITATION' : 'THIỆP MỜI THÀNH HÔN'}
                    </span>
                    <div className={styles.monogram}>H ♡ H</div>
                  </div>

                  {/* Couple Avatars Vignette */}
                  <div className={styles.avatarsRow}>
                    <div className={styles.avatarPill}>
                      <img
                        src={weddingConfig.groom.avatar}
                        alt={weddingConfig.groom.name}
                        className={styles.avatarImg}
                      />
                      <span className={styles.avatarRole}>{weddingConfig.groom.shortName}</span>
                    </div>

                    <div className={styles.avatarHeartIcon}>♡</div>

                    <div className={styles.avatarPill}>
                      <img
                        src={weddingConfig.bride.avatar}
                        alt={weddingConfig.bride.name}
                        className={styles.avatarImg}
                      />
                      <span className={styles.avatarRole}>{weddingConfig.bride.shortName}</span>
                    </div>
                  </div>

                  {/* Couple Names */}
                  <h2 className={styles.coupleNames}>
                    <span className={styles.namePart}>{weddingConfig.groom.name}</span>
                    <span className={styles.heartPart}>♡</span>
                    <span className={styles.namePart}>{weddingConfig.bride.name}</span>
                  </h2>

                  <div className={styles.ornateLine}>
                    <span>❦</span>
                  </div>

                  {/* Dates of Birth & Parents Details */}
                  <div className={styles.detailsGrid}>
                    <div className={styles.detailCol}>
                      <span className={styles.roleLabel}>{t.intro.groomRole}</span>
                      <strong className={styles.personNameText}>{weddingConfig.groom.name}</strong>
                      <span className={styles.dobBadge}>{t.intro.dobLabel} {t.intro.groomDob}</span>
                      <span className={styles.parentText}>
                        {t.intro.sonOf} <strong>{t.intro.groomParents}</strong>
                      </span>
                    </div>

                    <div className={styles.centerAmps}>&amp;</div>

                    <div className={styles.detailCol}>
                      <span className={styles.roleLabel}>{t.intro.brideRole}</span>
                      <strong className={styles.personNameText}>{weddingConfig.bride.name}</strong>
                      <span className={styles.dobBadge}>{t.intro.dobLabel} {t.intro.brideDob}</span>
                      <span className={styles.parentText}>
                        {t.intro.daughterOf} <strong>{t.intro.brideParents}</strong>
                      </span>
                    </div>
                  </div>

                  {/* Reception Date & Ceremony Address */}
                  <div className={styles.eventInfoBar}>
                    <div className={styles.eventRow}>
                      <Calendar size={14} color="var(--gold-primary)" />
                      <span>{t.countdown.fullDate}</span>
                    </div>
                    <div className={styles.eventRow}>
                      <MapPin size={14} color="var(--gold-primary)" />
                      <span>{t.venue.addressText}</span>
                    </div>
                    <div className={styles.eventRow}>
                      <MapPin size={14} color="var(--gold-primary)" />
                      <span>{t.venue.coordinatesLabel}: {weddingConfig.venue.coordinates.latitude}, {weddingConfig.venue.coordinates.longitude}</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Envelope Front Pocket */}
              <div className={styles.envelopePocketFront}>
                <div className={`${styles.cornerP} ${styles.cpTopLeft}`} />
                <div className={`${styles.cornerP} ${styles.cpTopRight}`} />
                <div className={`${styles.cornerP} ${styles.cpBottomLeft}`} />
                <div className={`${styles.cornerP} ${styles.cpBottomRight}`} />

                {phase === 'closed' && (
                  <div className={styles.frontPocketCover}>
                    <span className={styles.frontMonogram}>H ♡ H</span>
                    <h1 className={styles.frontNames}>
                      {weddingConfig.groom.shortName} &amp; {weddingConfig.bride.shortName}
                    </h1>
                    <span className={styles.frontDatePill}>
                      {weddingConfig.event.dateDisplay}
                    </span>
                    <p className={styles.frontQuote}>
                      {t.envelope.invitation}
                    </p>
                  </div>
                )}
              </div>

              {/* 3D Envelope Top Triangular Flap */}
              <motion.div
                className={styles.envelopeFlap}
                style={{ zIndex: phase === 'closed' ? 15 : 4 }}
                animate={
                  phase === 'closed'
                    ? { rotateX: 0 }
                    : {
                        rotateX: -180,
                        transition: { duration: 0.7, ease: [0.25, 1, 0.5, 1] },
                      }
                }
              >
                <div className={styles.flapTriangle} />
              </motion.div>

              {/* ══════════════════════════════════════════════════════
                  SPARKLING EFFECT AT THE CARD OPENING POINT
                  (No button — user presses this sparkling point to open!)
                  ══════════════════════════════════════════════════════ */}
              {phase === 'closed' && (
                <motion.button
                  type="button"
                  className={styles.sparkleOpeningPoint}
                  onClick={handleSparkleClick}
                  tabIndex={0}
                  onKeyDown={handleSparkleKeyDown}
                  aria-label="Mở thiệp cưới"
                  id="sparkle-card-opening-point"
                  initial={{ scale: 1 }}
                  whileHover={{ scale: 1.12 }}
                  whileTap={{ scale: 0.94 }}
                >
                  {/* Concentric Pulsing Light Rings */}
                  <div className={styles.pulseRingOuter} />
                  <div className={styles.pulseRingInner} />

                  {/* Rotating Diamond Light Flare */}
                  <div className={styles.diamondLightFlare} />

                  {/* Multiple Glittering Sparkling Stars around the opening point */}
                  <span className={`${styles.sparkleStar} ${styles.star1}`}>✦</span>
                  <span className={`${styles.sparkleStar} ${styles.star2}`}>✧</span>
                  <span className={`${styles.sparkleStar} ${styles.star3}`}>✦</span>
                  <span className={`${styles.sparkleStar} ${styles.star4}`}>★</span>
                  <span className={`${styles.sparkleStar} ${styles.star5}`}>✧</span>
                  <span className={`${styles.sparkleStar} ${styles.star6}`}>✦</span>
                  <span className={`${styles.sparkleStar} ${styles.star7}`}>★</span>
                  <span className={`${styles.sparkleStar} ${styles.star8}`}>✧</span>

                  {/* Center Golden Wax Seal with Embossed Monogram */}
                  <div className={styles.centerSparkleSeal}>
                    <span className={styles.sealMonogramText}>H ♡ H</span>
                    <div className={styles.sealSpecularShine} />
                  </div>
                </motion.button>
              )}
            </motion.div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
