import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import styles from './LanguageToggle.module.css';

export default function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className={styles.toggleWrapper}>
      <div className={styles.toggleButton} role="group" aria-label="Language selector">
        <button
          type="button"
          onClick={() => setLanguage('vi')}
          className={`${styles.optionPill} ${language === 'vi' ? styles.active : ''}`}
          aria-label="Switch to Vietnamese"
          aria-pressed={language === 'vi'}
          title="Vietnamese"
        >
          <span className={styles.langText}>{'Ti\u1ebfng Vi\u1ec7t'}</span>
        </button>
        <button
          type="button"
          onClick={() => setLanguage('en')}
          className={`${styles.optionPill} ${language === 'en' ? styles.active : ''}`}
          aria-label="Switch to English"
          aria-pressed={language === 'en'}
          title="English"
        >
          <span className={styles.langText}>English</span>
        </button>
      </div>
    </div>
  );
}
