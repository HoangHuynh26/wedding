import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext(null);

export const translations = {
  vi: {
    langCode: 'VI',
    toggleLabel: 'English',
    envelope: {
      header: 'THIỆP MỜI THÀNH HÔN',
      subHeader: 'WEDDING INVITATION',
      invitation: 'Trân trọng kính mời quý khách đến dự tiệc mừng ngày hạnh phúc của chúng mình.',
      tapToOpen: 'Chạm Để Mở Thiệp',
      audioNote: '(Nhạc nền "WHERE IS MY HUSBAND!" tự động phát khi mở)',
    },
    hero: {
      subtitle: 'WE ARE GETTING MARRIED',
      scroll: 'Cuộn để khám phá',
      date: '17 · 01 · 2027',
    },
    intro: {
      tag: 'LỜI NGỎ / INVITATION',
      title: 'Hành Trình Yêu Thương',
      quote: '“Hạnh phúc không phải là điểm đến, mà là một hành trình cùng nhau sẻ chia từng khoảnh khắc ngọt ngào lẫn thử thách. Chúng mình trân quý từng ngày tháng đã qua và hân hoan bước vào chương mới của cuộc đời.”',
      subtext: 'Trân trọng kính mời quý gia đình, người thân và bạn bè đến chung vui trong ngày trọng đại của chúng mình.',
      groomRole: 'Chú Rể / Groom',
      brideRole: 'Cô Dâu / Bride',
      dobLabel: 'Sinh ngày:',
      sonOf: 'Hôn tử của:',
      daughterOf: 'Ái nữ của:',
      groomDob: '14/10/1997',
      brideDob: '23/11/1999',
      groomParents: 'Ông Trần Đình Lý',
      brideParents: 'Ông Nguyễn Thanh Tâm & Bà Nguyễn Xuân Mai',
      groomBio: 'Một chàng trai chân thành, ấm áp và luôn trân trọng từng khoảnh khắc bình yên bên gia đình và người thương.',
      brideBio: 'Cô gái dịu dàng, thông minh và tràn đầy năng lượng tích cực, luôn mang lại nụ cười và sự ấm áp cho mọi người.',
    },
    story: {
      tag: 'CÂU CHUYỆN TÌNH YÊU',
      title: 'Our Love Story',
      milestones: [
        {
          year: '2022',
          title: 'Lần Đầu Gặp Gỡ',
          subtitle: 'Một chiều thu dịu dàng tại góc quán quen',
          description: 'Chúng mình tình cờ gặp nhau tại một buổi workshop nghệ thuật. Ánh nhìn đầu tiên, nụ cười bỡ ngỡ và câu chuyện kéo dài đến khi phố xá đã lên đèn.',
        },
        {
          year: '2023',
          title: 'Hẹn Hò & Gắn Kết',
          subtitle: 'Khi hai trái tim cùng chung nhịp đập',
          description: 'Buổi hẹn hò chính thức đầu tiên với bao bồi hồi rung động. Những lời sẻ chia chân thành về ước mơ và tương lai đã gắn kết hai tâm hồn lại gần nhau hơn.',
        },
        {
          year: '2025',
          title: 'Trưởng Thành Bên Nhau',
          subtitle: 'Vượt qua thử thách và cùng nhau đi khắp nơi',
          description: 'Cùng nhau đi qua nhiều vùng đất mới, học cách thấu hiểu, kiên nhẫn và luôn là điểm tựa bình yên nhất của nhau trong mọi chặng đường.',
        },
        {
          year: '2026',
          title: 'Lời Hứa Trọn Đời',
          subtitle: 'Khoảnh khắc thiêng liêng dưới hoàng hôn',
          description: 'Dưới ánh hoàng hôn rực rỡ, chiếc nhẫn được trao đi cùng lời hẹn ước trăm năm. Giọt nước mắt hạnh phúc và nụ cười rạng ngời: "Em đồng ý!".',
        },
        {
          year: '2027',
          title: 'Ngày Thành Hôn',
          subtitle: 'Khởi đầu cho chương hạnh phúc mới',
          description: 'Hôm nay, ngày 17.01.2027, trong sự chúc phúc của hai bên gia đình và bè bạn, chúng mình chính thức nắm tay nhau bước vào ngưỡng cửa hôn nhân.',
        },
      ],
    },
    countdown: {
      tag: 'ĐẾM NGƯỢC THỜI GIAN',
      title: 'Cùng Đếm Ngược Đến Ngày Chung Đôi',
      days: 'NGÀY',
      hours: 'GIỜ',
      minutes: 'PHÚT',
      seconds: 'GIÂY',
      fullDate: 'Chủ Nhật, 17 Tháng 01, 2027 • 17:30',
    },
    video: {
      tag: 'THƯỚC PHIM KỶ NIỆM',
      title: 'Our Memories',
      captionTitle: 'Từng Khoảnh Khắc Bên Nhau',
      captionText: 'Ghi lại những nụ cười, ánh mắt và những chuyến đi đong đầy yêu thương của Đình Huy & Thu Hiền.',
    },
    gallery: {
      tag: 'KHOẢNH KHẮC NGỌT NGÀO',
      title: 'Album Kỷ Niệm',
      photos: [
        { title: 'Khoảnh Khắc Bình Yên', caption: 'Nụ cười hạnh phúc trong ánh nắng sớm mai' },
        { title: 'Lời Hẹn Ước', caption: 'Bàn tay nắm chặt không rời' },
        { title: 'Tình Yêu Nở Hoa', caption: 'Giữa không gian ngập tràn hoa tươi và ánh sáng' },
        { title: 'Ánh Nhìn Ngọt Ngào', caption: 'Đôi mắt chứa đựng cả bầu trời thương nhớ' },
        { title: 'Chuyến Đi Kỷ Niệm', caption: 'Cùng nhau ngắm hoàng hôn buông xuống chân đồi' },
        { title: 'Vũ Điệu Hạnh Phúc', caption: 'Xoay tròn trong giai điệu của tình yêu' },
      ],
    },
    venue: {
      tag: 'ĐỊA ĐIỂM TỔ CHỨC',
      title: 'Nơi Hạnh Phúc Đơm Hoa',
      hall: 'Grand Ballroom - Sảnh Hoàng Gia',
      timeTitle: 'Thời Gian',
      timeDetail: '17:30 (Bắt đầu đón khách)',
      addressTitle: 'Địa Chỉ Hôn Lễ',
      addressText: '1322/768, Thiện Tân Quarter, Trảng Dài Ward, Đồng Nai City',
      mapsBtn: 'OPEN GOOGLE MAPS',
      coordinatesLabel: 'T\u1ecda \u0111\u1ed9',
      schedule: [
        '17:30 - Đón khách & Welcome Drinks',
        '18:30 - Khai tiệc & Nghi lễ thành hôn',
        '19:00 - Tiệc cưới thân mật & Âm nhạc',
      ],
    },
    qrcode: {
      notice: 'SCAN TO OPEN OUR INVITATION',
      title: 'Thiệp Cưới Điện Tử',
      subtext: '“Chia sẻ ngày vui cùng những người bạn yêu quý.”',
      copyBtn: 'Sao chép link thiệp',
      copiedToast: 'Đã sao chép liên kết!',
      shareBtn: 'Chia sẻ thiệp cưới',
    },
    rsvp: {
      before: 'Before you go...',
      quote: '“Chúng mình rất mong muốn được cùng bạn sẻ chia khoảnh khắc thiêng liêng và ý nghĩa này.”',
      joining: 'ARE YOU JOINING US?',
      formTitle: 'Xác Nhận Tham Dự',
      formSubtitle: 'Để gia đình chuẩn bị chu đáo nhất, xin bạn vui lòng xác nhận trước ngày 05.01.2027.',
      nameLabel: 'Họ và Tên / Your Name *',
      namePlaceholder: 'Ví dụ: Nguyễn Văn Nam',
      locationLabel: 'Bạn đến từ đâu? / Where are you from? *',
      locationPlaceholder: 'Ví dụ: Đồng Nai / TP. Hồ Chí Minh / Hà Nội',
      submitBtn: "YES, I'LL BE THERE",
      confirming: 'Đang xác nhận...',
      validationNameRequired: 'Vui lòng nhập họ và tên của bạn',
      validationNameShort: 'Tên phải có ít nhất 2 ký tự',
      validationLocationRequired: 'Vui lòng nhập tỉnh/thành phố bạn đang ở',
      validationLocationShort: 'Địa điểm phải có ít nhất 2 ký tự',
      successHeading: "WE'RE SO HAPPY YOU'LL BE THERE!",
      thankYou: 'Cảm ơn bạn,',
      successMsg: '“Cảm ơn bạn đã xác nhận tham dự. Chúng mình rất mong chờ được đón tiếp và chung vui cùng bạn trong ngày trọng đại!”',
      guestLabel: 'Khách mời:',
      fromLabel: 'Nơi đến:',
      statusLabel: 'Tình trạng:',
      statusConfirmed: 'Đã xác nhận tham dự ✓',
      resetBtn: 'Đăng ký thêm cho người thân hoặc gửi phản hồi mới',
    },
    nav: {
      story: 'CÂU CHUYỆN',
      storySub: 'OUR STORY',
      date: 'NGÀY CHUNG ĐÔI',
      dateSub: 'WEDDING DATE',
      video: 'THƯỚC PHIM',
      videoSub: 'MEMORIES',
      gallery: 'ALBUM KỶ NIỆM',
      gallerySub: 'PHOTO GALLERY',
      venue: 'ĐỊA ĐIỂM CƯỚI',
      venueSub: 'VENUE & MAP',
      qr: 'THIỆP QR',
      qrSub: 'QR INVITATION',
      rsvp: 'XÁC NHẬN THAM DỰ',
      rsvpSub: 'RSVP',
      reopen: 'Xem Bì Thư / Thiệp Mời Gốc',
    },
    footer: {
      quote: '“Cảm ơn bạn đã luôn là một phần quan trọng trong hành trình thanh xuân và hạnh phúc của chúng mình.”',
      tagline: 'With All Our Love • Made with ♡ for our special day',
    },
  },

  en: {
    langCode: 'EN',
    toggleLabel: 'Tiếng Việt',
    envelope: {
      header: 'WEDDING INVITATION',
      subHeader: 'SAVE THE DATE',
      invitation: 'Together with our families, we joyfully invite you to celebrate our wedding day.',
      tapToOpen: 'Tap To Open Invitation',
      audioNote: '(Melody "WHERE IS MY HUSBAND!" plays automatically upon opening)',
    },
    hero: {
      subtitle: 'WE ARE GETTING MARRIED',
      scroll: 'Scroll to discover',
      date: '17 · 01 · 2027',
    },
    intro: {
      tag: 'WELCOME & GREETING',
      title: 'A Journey of Love',
      quote: '“Happiness is not a destination, but a beautiful journey of sharing sweet smiles, supporting each other through every challenge, and cherishing every chapter together.”',
      subtext: 'Together with our families, we joyfully invite you to celebrate our special wedding day with us.',
      groomRole: 'The Groom',
      brideRole: 'The Bride',
      dobLabel: 'Born on:',
      sonOf: 'Son of:',
      daughterOf: 'Daughter of:',
      groomDob: '14/10/1997',
      brideDob: '23/11/1999',
      groomParents: 'Mr. Tran Dinh Ly',
      brideParents: 'Mr. Nguyen Thanh Tam & Mrs. Nguyen Xuan Mai',
      groomBio: 'A sincere, warm-hearted man who always treasures every peaceful moment with family and his beloved.',
      brideBio: 'A gentle, radiant and intelligent woman who brings warm smiles, joy and positivity to everyone around her.',
    },
    story: {
      tag: 'OUR LOVE STORY',
      title: 'How It All Began',
      milestones: [
        {
          year: '2022',
          title: 'When We First Met',
          subtitle: 'A sweet autumn afternoon at a cozy corner',
          description: 'A serendipitous encounter at an art workshop. First shy glances, warm smiles, and a conversation that lasted well into the twilight hours.',
        },
        {
          year: '2023',
          title: 'Our First Official Date',
          subtitle: 'When two souls harmonized into one melody',
          description: 'Our first official date filled with fluttering excitement. Sincere talks about dreams and the future drew our hearts closer together.',
        },
        {
          year: '2025',
          title: 'Growing Together',
          subtitle: 'Exploring new horizons side by side',
          description: 'Traveling hand in hand across scenic landscapes, learning empathy, patience, and always being each other’s safest sanctuary.',
        },
        {
          year: '2026',
          title: 'She Said YES!',
          subtitle: 'A golden sunset promise on the shore',
          description: 'Under the golden sunset, a ring was offered along with a promise for eternity. Tears of boundless joy and a radiant: "Yes, I do!".',
        },
        {
          year: '2027',
          title: 'Our Wedding Day',
          subtitle: 'The beginning of our lifelong forever',
          description: 'Today, January 17, 2027, surrounded by the blessings of beloved family and friends, we step hand in hand into the sacred bond of marriage.',
        },
      ],
    },
    countdown: {
      tag: 'WEDDING COUNTDOWN',
      title: 'Counting Down Every Moment',
      days: 'DAYS',
      hours: 'HOURS',
      minutes: 'MINUTES',
      seconds: 'SECONDS',
      fullDate: 'Sunday, January 17, 2027 • 17:30',
    },
    video: {
      tag: 'OUR MEMORIES',
      title: 'Cinematic Highlights',
      captionTitle: 'Moments Held In Time',
      captionText: 'A glimpse into the cherished smiles, gentle glances, and unforgettable journeys of Dinh Huy & Thu Hien.',
    },
    gallery: {
      tag: 'CHERISHED MOMENTS',
      title: 'Photo Album',
      photos: [
        { title: 'Serene Morning', caption: 'Radiant smiles under the soft morning sun' },
        { title: 'Our Promise', caption: 'Holding hands towards forever' },
        { title: 'Blooming Love', caption: 'Surrounded by blooming flowers and golden glow' },
        { title: 'Sweet Glances', caption: 'Eyes that reflect a whole sky of love' },
        { title: 'Memorable Getaway', caption: 'Watching sunset paint the hillside together' },
        { title: 'Dance of Joy', caption: 'Spinning together in the melody of romance' },
      ],
    },
    venue: {
      tag: 'WEDDING VENUE',
      title: 'Where Love Begins',
      hall: 'Imperial Grand Ballroom',
      timeTitle: 'Date & Time',
      timeDetail: '17:30 (Guest reception begins)',
      addressTitle: 'Ceremony Address',
      addressText: '1322/768, Thien Tan Quarter, Trang Dai Ward, Dong Nai City',
      mapsBtn: 'OPEN GOOGLE MAPS',
      coordinatesLabel: 'Coordinates',
      schedule: [
        '17:30 - Welcome Reception & Cocktail Drinks',
        '18:30 - Wedding Ceremony & Nuptials',
        '19:00 - Dinner Banquet & Live Music',
      ],
    },
    qrcode: {
      notice: 'SCAN TO OPEN OUR INVITATION',
      title: 'Digital Invitation',
      subtext: '“Share our special day with someone you love.”',
      copyBtn: 'Copy Invitation Link',
      copiedToast: 'Link copied to clipboard!',
      shareBtn: 'Share Invitation',
    },
    rsvp: {
      before: 'Before you go...',
      quote: '“We would be deeply honored to have your presence to celebrate this meaningful milestone with us.”',
      joining: 'ARE YOU JOINING US?',
      formTitle: 'RSVP Confirmation',
      formSubtitle: 'To help our families prepare warmly and seat everyone comfortably, please kindly confirm by Jan 5, 2027.',
      nameLabel: 'Your Full Name *',
      namePlaceholder: 'e.g. Alexander Nguyen',
      locationLabel: 'Where are you traveling from? (City / Country) *',
      locationPlaceholder: 'e.g. Dong Nai / Ho Chi Minh City / Singapore',
      submitBtn: "YES, I'LL BE THERE",
      confirming: 'Confirming attendance...',
      validationNameRequired: 'Please enter your full name',
      validationNameShort: 'Name must be at least 2 characters',
      validationLocationRequired: 'Please enter your location or city',
      validationLocationShort: 'Location must be at least 2 characters',
      successHeading: "WE'RE SO HAPPY YOU'LL BE THERE!",
      thankYou: 'Thank you,',
      successMsg: '“Thank you for confirming your attendance. We cannot wait to celebrate this magical day with you!”',
      guestLabel: 'Guest:',
      fromLabel: 'From:',
      statusLabel: 'Status:',
      statusConfirmed: 'Attendance Confirmed ✓',
      resetBtn: 'Submit another RSVP for family members',
    },
    nav: {
      story: 'OUR STORY',
      storySub: 'CÂU CHUYỆN',
      date: 'WEDDING DATE',
      dateSub: 'NGÀY CƯỚI',
      video: 'OUR MEMORIES',
      videoSub: 'THƯỚC PHIM',
      gallery: 'PHOTO GALLERY',
      gallerySub: 'ALBUM ẢNH',
      venue: 'VENUE & MAP',
      venueSub: 'ĐỊA ĐIỂM',
      qr: 'QR INVITATION',
      qrSub: 'THIỆP QR',
      rsvp: 'RSVP ATTENDANCE',
      rsvpSub: 'XÁC NHẬN',
      reopen: 'Reopen Sealed Envelope',
    },
    footer: {
      quote: '“Thank you for being such an integral part of our youth and our journey towards happiness.”',
      tagline: 'With All Our Love • Made with ♡ for our special day',
    },
  },
};

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState(() => {
    try {
      return localStorage.getItem('wedding_lang') || 'vi';
    } catch {
      return 'vi';
    }
  });

  const setPreferredLanguage = (next) => {
    if (next !== 'vi' && next !== 'en') return;
    setLanguage(next);
    try {
      localStorage.setItem('wedding_lang', next);
    } catch {
      // Ignore
    }
  };

  const toggleLanguage = () => {
    setPreferredLanguage(language === 'vi' ? 'en' : 'vi');
  };

  const activeTranslations = translations[language] || translations.vi;
  const isVietnamese = language === 'vi';
  const t = {
    ...activeTranslations,
    countdown: {
      ...activeTranslations.countdown,
      fullDate: isVietnamese
        ? 'Ch\u1ee7 Nh\u1eadt, 17 Th\u00e1ng 01, 2027 \u2022 11:20 AM'
        : 'Sunday, January 17, 2027 \u2022 11:20 AM',
    },
    venue: {
      ...activeTranslations.venue,
      timeDetail: isVietnamese
        ? '11:20 AM (B\u1eaft \u0111\u1ea7u \u0111\u00f3n kh\u00e1ch)'
        : '11:20 AM (Guest reception begins)',
      schedule: [
        isVietnamese ? '11:20 AM - \u0110\u00f3n kh\u00e1ch & Welcome Drinks' : '11:20 AM - Welcome Reception & Cocktail Drinks',
        ...activeTranslations.venue.schedule.slice(1),
      ],
    },
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: setPreferredLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}

export default LanguageContext;
